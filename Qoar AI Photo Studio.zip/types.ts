
export interface EditedImageResult {
  imageB64: string;
  text: string | null;
}
